package com.ust.util.passwordEx.PasswordEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PasswordExApplicationTests {

	@Test
	void contextLoads() {
	}

}
