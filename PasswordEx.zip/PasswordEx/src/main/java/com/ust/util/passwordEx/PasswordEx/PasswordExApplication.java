package com.ust.util.passwordEx.PasswordEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PasswordExApplication {

	public static void main(String[] args) {
		SpringApplication.run(PasswordExApplication.class, args);
	}

}
